# ConfluencePageExtractor
Zapier custom app - ConfluencePageExtractor - extract page contents to support HubSpot blog creation
